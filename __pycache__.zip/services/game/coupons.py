from flask import request, jsonify
from flask_restx import Resource, Namespace, fields
from flask_jwt_extended import jwt_required
from models.model import Coupons
from models.model import Scores
from models.exts import db
import random
import string

coupons_ns = Namespace('Coupons', description='namespaces Scores ')

coupons_model = coupons_ns.model(
    "Coupons",
    {
        "id": fields.Integer(),
        "username": fields.String(),
        "coupons": fields.String(),
        "nombre_de_pieces": fields.Integer(),
    }
)


@coupons_ns.route("/generateCoupons/<string:username>")
class GenerateCodeCouponsRessource(Resource):

    
    @coupons_ns.marshal_list_with(coupons_model)
    @jwt_required()
    def get(self, username):
       # print(scores)
        '''Get all matches '''
        letters_and_digits = string.ascii_uppercase + string.digits
        code = ''.join(random.choices(letters_and_digits, k=6))
        
        
        new_user = Coupons(
            username=username,
            coupons=code,
            nombre_de_pieces = 10
        )
        new_user.save()

        return new_user 
    

@coupons_ns.route("/getMyCoupons/<string:username>")
class GenerateCodeCouponsRessource(Resource):


    @coupons_ns.marshal_list_with(coupons_model)
    @jwt_required()
    def get(self, username):
       # print(scores)
        '''Get all matches '''
        mycoupons = Coupons.query.filter_by(username=username).first()

        return mycoupons 


@coupons_ns.route("/addcoupons")
class addcouponsRessource(Resource):

   

    @coupons_ns.marshal_with(coupons_model)
    @jwt_required()
    def put(self):
        '''update score from users Coupons'''
        data = request.get_json()
        coupons=data.get('coupons')
        print(len(coupons))
        # if len(coupons) 
        user_to_update = Coupons.query.filter_by(
            coupons=coupons).first()
        
       
        if user_to_update:
            #print(user_to_update.username)
            username1=data.get('username')
            username2 = user_to_update.username
            print ( username1)
            print ( username2)

            scores_to_update_user1 = Scores.query.filter_by(
            username=username1).first_or_404()
            new_scores = scores_to_update_user1.scores + user_to_update.nombre_de_pieces
            print(new_scores)
            scores_to_update_user1.update(
           # username=username1,
            scores=new_scores
            )

            scores_to_update_user2 = Scores.query.filter_by(
            username=username2).first_or_404()
            new_scores   = scores_to_update_user2.scores + user_to_update.nombre_de_pieces
            #print(new_scores)
            scores_to_update_user2.update(
          #  username=username1,
            scores=new_scores
            )


            return user_to_update
        else:
            return "invalid"
        # print(user_to_update)
        
        

        # return scores_to_update


@coupons_ns.route("/newCoupons")
class addcouponsRessource(Resource):

   

    @coupons_ns.marshal_with(coupons_model)
    def post(self):
        '''update score from users Coupons'''
        data = request.get_json()
       
       
    
        new_coupons = Coupons(
            coupons=data.get('coupons'),
            username='admin',
            nombre_de_pieces=data.get('nombre_de_pieces')
            
        )
        new_coupons.save()
       
        return new_coupons